#pragma once
#include"adjList.h"
void BFS_adjList(graphType* g, int v);